package es.iessoterohernandez.daw.endes.ProyectoMaven;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class AppTest {

	@Test
	void test() {

	}

}

