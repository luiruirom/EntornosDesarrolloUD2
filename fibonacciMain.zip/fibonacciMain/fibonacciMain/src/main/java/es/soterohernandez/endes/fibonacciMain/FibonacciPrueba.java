package es.soterohernandez.endes.fibonacciMain;

import es.iessoterohernandez.daw.endes.ProyectoMaven.*;

public class FibonacciPrueba 
{
    public static void main( String[] args ){
    	App fibo = new App();    	
    	System.out.println(fibo);
    }
}
